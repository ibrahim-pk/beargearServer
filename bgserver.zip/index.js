const express = require('express');
const authRouter = require('./routers/auth/authRouter');
const cors=require('cors');
const myDB = require('./DB/db');
const orderRouter = require('./routers/order/orderRouter');
const productRouter = require('./routers/product/ProductRouter');
const categoryRouter = require('./routers/category/categoryRouter');
const popupRouter = require('./routers/popup/popupRouter');
const multer =require('multer')
const path=require('path')
const fs = require('fs');
const bannerRouter = require('./routers/banner/bannerRouter');
const supportRouter = require('./routers/supportUS/supportRouter');
const gallaryRouter = require('./routers/Gallary/gallaryRouter');

const app = express();

const port =process.env.PORT || 5000;


// Connect to MySQL
myDB.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL');
});




// const uploadDirectory = path.join(process.cwd(), 'public/uploads');

// // Ensure the uploads directory exists
// if (!fs.existsSync(uploadDirectory)) {
//   fs.mkdirSync(uploadDirectory, { recursive: true });
// }

//upload
// const upload = multer({
//   storage: multer.diskStorage({
//     destination: path.join(process.cwd(), 'public/uploads'),
//     filename: (req, file, cb) => {
//       const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
//       cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
//     },
//   }),
// });



// app.use((_req, res, next) => {
//   res.header('Access-Control-Allow-Origin', '*');
//   res.header('Access-Control-Allow-Headers', '*');

//   next();
// });
const corsOptions = {
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  headers: 'Content-Type, Authorization',
};

app.use(cors(corsOptions));
app.use(express.json())



app.use('/api/v1/user',authRouter)
app.use('/api/v1/orders',orderRouter)
app.use('/api/v1/product',productRouter)
app.use('/api/v1/category',categoryRouter)
app.use('/api/v1/banner',bannerRouter)
app.use('/api/v1/gallary',gallaryRouter)
app.use('/api/v1/support',supportRouter)
app.use('/api/v1/popup',popupRouter)

// app.post('/api/upload',(req,res)=>{
//   try {
//      upload.single('file')(req, res, (err) => {
//       if (err) {
//         return res.status(500).json({ error: err.message });
//       }

//       const filePath = req.file.path;
//       const fileUrl = `/uploads/${req.file.filename}`;

//       return res.status(200).json({ url: fileUrl });
//     });
//   } catch (error) {
//     console.error('Error uploading file:', error);
//     return res.status(500).json({ error: 'Internal Server Error' });
//   }

// })




app.get('/', (req, res) => {
  res.send('Hello BG Server!');
});


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
